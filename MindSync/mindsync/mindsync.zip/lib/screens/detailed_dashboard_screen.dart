import 'package:flutter/material.dart';
import '../widgets/app_background.dart';
import '../widgets/app_header.dart';

class DetailedDashboardScreen extends StatelessWidget {
  const DetailedDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AppBackground(
        child: Column(
          children: [
            const AppHeader(),
            const SizedBox(height: 20),
            Expanded(
              child: GridView.count(
                crossAxisCount: 2,
                padding: const EdgeInsets.all(20),
                crossAxisSpacing: 15,
                mainAxisSpacing: 15,
                children: [
                  _dashboardItem(context, "Mood Tracker", Icons.emoji_emotions, '/mood-tracker'),
                  _dashboardItem(context, "Guided Meditation", Icons.self_improvement, '/meditation'),
                  _dashboardItem(context, "Breathing Exercise", Icons.air, '/breathing'),
                  _dashboardItem(context, "Mindfulness Articles", Icons.article, '/articles'),
                  _dashboardItem(context, "Sleep Tracker", Icons.nights_stay, '/sleep-tracker'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _dashboardItem(BuildContext context, String title, IconData icon, String route) {
    return GestureDetector(
      onTap: () => Navigator.pushNamed(context, route),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.92),
          borderRadius: BorderRadius.circular(15),
          boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 10, spreadRadius: 2)],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 40, color: Colors.blueAccent),
            const SizedBox(height: 10),
            Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}
