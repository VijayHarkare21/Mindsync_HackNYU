import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';
import 'screens/login_screen.dart';
import 'screens/signup_screen.dart';
import 'screens/dashboard_screen.dart';
import 'screens/detailed_dashboard_screen.dart';
import 'screens/mood_tracker_screen.dart';
import 'screens/mindfulness_articles_screen.dart';

void main() {
  runApp(const MindSyncApp());
}

class MindSyncApp extends StatelessWidget {
  const MindSyncApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MindSync',
      theme: ThemeData(
        fontFamily: 'DarkerGrotesque',  // ✅ Custom Font
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Colors.white,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const SplashScreen(),
        '/login': (context) => const LoginScreen(),
        '/signup': (context) => const SignupScreen(),
        '/dashboard': (context) => const DashboardScreen(),
        '/detailed-dashboard': (context) => const DetailedDashboardScreen(),
        '/mood-tracker': (context) => const MoodTrackerScreen(),
        '/articles': (context) => const MindfulnessArticlesScreen(),
      },
    );
  }
}
